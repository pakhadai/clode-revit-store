"""
Скрипт для швидкого створення таблиць без Alembic
Запустіть: python create_tables.py
"""
import asyncio
from app.database import engine, Base
from app.models import user, product, order, subscription

async def init_models():
    async with engine.begin() as conn:
        # Спершу видаляємо всі існуючі таблиці (опціонально, для чистого старту)
        # await conn.run_sync(Base.metadata.drop_all)
        # Створюємо всі таблиці
        await conn.run_sync(Base.metadata.create_all)
    print("✅ Таблиці створено успішно!")

if __name__ == "__main__":
    asyncio.run(init_models())