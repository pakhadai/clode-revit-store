"""
OhMyRevit Backend Application
Маркетплейс для продажу архівів Revit
"""

__version__ = "1.0.0"
__author__ = "OhMyRevit Team"

# Не робимо імпорти тут, щоб уникнути циклічних залежностей